#include <iostream>
using namespace std;
typedef struct {
	double TUSO; 
	double MAUSO;
}PS;

void input(PS &P1) {
	cout << "Hay nhap TUSO va PHANSO " << endl;
	cin >> P1.TUSO;
	cin >> P1.MAUSO;
}

void output(PS P1) {
	cout << P1.TUSO / P1.MAUSO;
}

PS operator+(PS P1, PS P2) {
	PS result;
	result.TUSO = P1.MAUSO * P2.TUSO + P1.TUSO * P2.MAUSO;
	result.MAUSO = P1.MAUSO * P2.MAUSO;
	return result;
}

PS operator-(PS P1, PS P2) {
	PS result;
	result.TUSO = P1.TUSO * P2.MAUSO - P1.MAUSO * P2.TUSO;
	result.MAUSO = P1.TUSO * P2.TUSO;
	return result;
}

PS operator*(PS P1, PS P2) {
	PS result;
	result.TUSO = P1.TUSO * P2.TUSO;
	result.MAUSO = P1.MAUSO * P2.MAUSO;
	return result;
}

PS operator/(PS P1, PS P2) {
	PS result;
	result.TUSO = P1.TUSO * P2.MAUSO;
	result.MAUSO = P1.MAUSO * P2.TUSO;
	return result;
}
int main() {
	PS P1;
	PS P2;
	input(P1);
	input(P2);
	output(P1 + P2);
}