#include <iostream>
using namespace std;
int main()
{
	int lastday;
	int date, month, year;
	cout << "Hay nhap ngay ";
	cin >> date;
	cout << "Hay nhap thang ";
	cin >> month;
	cout << "Hay nhap nam ";
	cin >> year;
	switch (month) {
	case 1: case 3: case 5: case 7: case 9: case 11:
		lastday = 31;
		break;
	case 4:case 6: case 8: case 10: case 12:
		lastday = 30;
		break;
	case 2: 
		if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
			lastday = 29;
		else lastday = 28;
	}
	if (date < lastday) {
		date = date + 1;
		month = month;
		year = year;

	}
	else {
		if (month != 12) {
			date = date + 1;
			month = month + 1;
			year = year;
		}
		else {
			date = date + 1;
			month = month + 1;
			year = year+ 1;
		}
	}
	cout << "Ngay thang tiep theo la ";
	cout << date << "/" << month << "/" << year;
}
