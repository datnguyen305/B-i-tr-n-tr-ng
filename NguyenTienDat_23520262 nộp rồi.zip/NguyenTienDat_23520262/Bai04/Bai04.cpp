#include <iostream>
using namespace std;
typedef struct {
    double TUSO;
    double MAUSO;
}PS;

void input(PS array[], int n) {
    for (int i = 0; i < n; i++) {
        cout << "Hay nhap TUSO va MAUSO "<< endl;
        cin >> array[i].TUSO;
        cin >> array[i].MAUSO;
    }
}

void outputmang(PS array[], int n) {
    for (int i = 0; i < n; i++) {
        cout << "PHAN SO THU " << i + 1 << " ";
        cout << array[i].TUSO << "/";
        cout << array[i].MAUSO;
    }
}

void output(PS P1) {
    cout << P1.TUSO << "/" << P1.MAUSO << endl;
}

PS timsolonnhat(PS array[], int n){
    PS MAX = array[0];
    for (int i = 1; i < n; i++) {
        if (array[i].TUSO * MAX.MAUSO > MAX.TUSO * array[i].MAUSO) {
            MAX = array[i];
        }
    }
    return MAX;
}

void sapxeptangdan(PS array[], int n) {
    int i = 0;
    for (i = 0; i < n; i++) {
        for (int j = i + 1; j < n ; j++) {
            if (array[i].TUSO*array[j].MAUSO > array[j].TUSO*array[i].MAUSO) {
                PS tempt = array[i];
                array[i] = array[j];
                array[j] = tempt;
            }
        }
    }
}

void sapxepgiamdan(PS array[], int n) {
    int i = 0;;
    for (i = 0; i < n; i++) {
        for (int j = i+ 1; j < n; j++) {
            if (array[i].TUSO * array[j].MAUSO < array[j].TUSO * array[i].MAUSO) {
                PS tempt = array[i];
                array[i] = array[j];
                array[j] = tempt;
            }
        }
    }
}

int main()
{
    int n;
    PS array[100];
    cout << "Hay nhap so luong PS " <<endl;
    cin >> n;
    input(array, n);
    output(timsolonnhat(array, n));
    sapxeptangdan(array, n);
    outputmang(array, n);

}




