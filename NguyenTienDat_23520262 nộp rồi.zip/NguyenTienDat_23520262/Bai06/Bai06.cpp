#include <iostream>
#include<string>
using namespace std;
typedef struct {
	string ten;
	double diemtoan;
	double diemvan;
}HS;

void input(HS danhsach[], int n) {
	for (int i = 0; i < n; i++) {
		cout << "Hay nhap ten " <<endl;     
		cin>>danhsach[i].ten;
		cout << "Hay nhap diem toan "<<endl;
		cin >> danhsach[i].diemtoan;
		cout << "Hay nhap diem van " << endl;
		cin >> danhsach[i].diemvan;
	}
}

double diemtrungbinh(double diemtoan, double diemvan) {
	int result = (diemtoan + diemvan) / 2;
	return result;
}

void output(HS MAX) {
	cout << "Ten hoc sinh ";
	cout << MAX.ten;
	cout << "Diem toan ";
	cout << MAX.diemtoan;
	cout << "Diem van ";
	cout << MAX.diemvan;
	cout << "Diem trung binh ";
	cout << diemtrungbinh(MAX.diemtoan, MAX.diemvan);
}

HS timdiemtrungbinhlonnhat(HS danhsach[], int n) {
	HS MAX = danhsach[0];
	for (int i = 1; i < n; i++) {
		if (diemtrungbinh(danhsach[i].diemtoan, danhsach[i].diemvan) > diemtrungbinh(MAX.diemtoan, MAX.diemvan)) {
			MAX = danhsach[i];
		}
	}
	return MAX;
}

HS timdiemtrungbinhnhonhat(HS danhsach[], int n) {
	HS MIN = danhsach[0];
	for (int i = 1; i < n; i++) {
		if (diemtrungbinh(danhsach[i].diemtoan, danhsach[i].diemvan) < diemtrungbinh(MIN.diemtoan, MIN.diemvan)) {
			MIN = danhsach[i];
		}
	}
	return MIN;
}

int main() {
	int n;
	HS danhsach[10];
	cout << "Hay nhap so luong hoc sinh ";
	cin >> n;
	input(danhsach, n);
	output(timdiemtrungbinhlonnhat(danhsach, n));
	output(timdiemtrungbinhnhonhat(danhsach, n));
}